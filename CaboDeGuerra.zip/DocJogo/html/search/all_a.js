var searchData=
[
  ['thread_5fconferevencedor',['thread_confereVencedor',['../Threads_8h.html#aa0108cf35aaeaca2c7cd58aaca1c43f9',1,'Threads.c']]],
  ['thread_5fentrada',['thread_entrada',['../Threads_8h.html#aa6424ae95e73f47512987a8285b8cd7f',1,'Threads.c']]],
  ['thread_5fsaida',['thread_saida',['../Threads_8h.html#a696bfc8e3b680b42bb93207c40ab4a8c',1,'Threads.c']]],
  ['threads',['Threads',['../structThreads.html',1,'']]],
  ['threads_2eh',['Threads.h',['../Threads_8h.html',1,'']]]
];
