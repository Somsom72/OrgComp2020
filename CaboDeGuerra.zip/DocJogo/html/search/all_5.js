var searchData=
[
  ['jogador',['Jogador',['../structJogador.html',1,'']]],
  ['jogadores_2eh',['Jogadores.h',['../Jogadores_8h.html',1,'']]]
];
