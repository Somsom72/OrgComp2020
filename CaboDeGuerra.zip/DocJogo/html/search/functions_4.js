var searchData=
[
  ['imprimesaida',['imprimeSaida',['../EntradaSaida_8h.html#af94ff03473fddf9ba34810a87f7199f2',1,'EntradaSaida.c']]],
  ['inicializarinfos',['inicializarInfos',['../Jogadores_8h.html#a5a4b7ed741cc21fafebc4d33e08a7fac',1,'Jogadores.c']]],
  ['inicializarjogador',['inicializarJogador',['../Jogadores_8h.html#ace2337e4f06fad2452ffd28edb3a019b',1,'Jogadores.c']]],
  ['init_5fall_5fsem',['init_all_sem',['../Semaforo_8h.html#a584ba0c628c7374e6749a9467a27cd83',1,'Semaforo.c']]]
];
