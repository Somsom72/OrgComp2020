var searchData=
[
  ['jogador',['Jogador',['../structJogador.html',1,'']]]
];
