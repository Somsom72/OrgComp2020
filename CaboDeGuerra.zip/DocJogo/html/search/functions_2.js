var searchData=
[
  ['destroy_5fall_5fsem',['destroy_all_sem',['../Semaforo_8h.html#ab5e109ee77a7c4d1663d0851ff5b127b',1,'Semaforo.c']]],
  ['determinavencedor',['determinaVencedor',['../Jogadores_8h.html#a78332f77b3d5ca1a9c9dff4d87587bfb',1,'Jogadores.c']]]
];
