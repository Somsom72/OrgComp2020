var searchData=
[
  ['infos',['Infos',['../structInfos.html',1,'']]]
];
