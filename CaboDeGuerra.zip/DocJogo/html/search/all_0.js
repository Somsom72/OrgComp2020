var searchData=
[
  ['atualizaplacar',['atualizaPlacar',['../Jogadores_8h.html#af1f1a95b957533b5adb19099fe67b8c1',1,'Jogadores.c']]]
];
