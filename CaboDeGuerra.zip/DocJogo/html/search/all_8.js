var searchData=
[
  ['remove_5fitem',['remove_item',['../Semaforo_8h.html#adb14f7e3d6b7bca73e49b812065eebe4',1,'Semaforo.c']]]
];
